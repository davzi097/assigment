﻿using EFCoreHotel_RazorPages.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EFCoreHotel_RazorPages.Services.ADOServices.BookingService
{
    public class ADONetBookingService
    {
        private IConfiguration configuration { get; }
        public ADONetBookingService(IConfiguration config)
        {
            configuration = config;
        }
        public List<Booking> GetBookings()
        {
            string connectionString = configuration.GetConnectionString("HotelConnection");
            List<Booking> lst = new List<Booking>();
            string sql = "Select * From Booking ";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(sql, connection);
                using (SqlDataReader dataReader = command.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Booking booking = new Booking();
                        booking.BookingId = Convert.ToInt32(dataReader[0]);
                        booking.HotelNo = Convert.ToInt32(dataReader[1]);
                        booking.GuestNo = Convert.ToInt32(dataReader[2]);
                        booking.DateFrom = Convert.ToDateTime(dataReader[3]);
                        booking.DateTo = Convert.ToDateTime(dataReader[4]);
                        booking.RoomNo = Convert.ToInt32(dataReader[5]);
                        lst.Add(booking);
                    }
                }
            }
            return lst;
        }


    }
}
