﻿using EFCoreHotel_RazorPages.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EFCoreHotel_RazorPages.Services.ADOServices.GuestService
{
    public class ADONetGuestService
    {
        private IConfiguration configuration { get; }
        public ADONetGuestService(IConfiguration config)
        {
            configuration = config;
        }
        public List<Guest> GetGuests()
        {
            string connectionString = configuration.GetConnectionString("HotelConnection");
            List<Guest> lst = new List<Guest>();
            string sql = "Select * From Guest";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(sql, connection);
                using (SqlDataReader dataReader = command.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Guest guest = new Guest();
                        guest.GuestNo = Convert.ToInt32(dataReader[0]);
                        guest.Name = Convert.ToString(dataReader[1]);
                        guest.Address = Convert.ToString(dataReader[2]);

                        lst.Add(guest);
                    }
                }
            }
            return lst;
        }

        public List<Guest> GetGFR()
        {
            string connectionString = configuration.GetConnectionString("HotelConnection");
            List<Guest> lst = new List<Guest>();
            string sql = "SELECT * FROM Guest WHERE Address LIKE '%Roskilde%'";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(sql, connection);
                using (SqlDataReader dataReader = command.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Guest guest = new Guest();
                        guest.GuestNo = Convert.ToInt32(dataReader[0]);
                        guest.Name = Convert.ToString(dataReader[1]);
                        guest.Address = Convert.ToString(dataReader[2]);

                        lst.Add(guest);
                    }
                }
            }
            return lst;
        }

        public List<Booking> GetBOEG(int Guest_No)
        {

            string connectionString = configuration.GetConnectionString("HotelConnection");
            List<Booking> lst = new List<Booking>();
            string sql = $"Select * From Booking WHERE Booking.Guest_No = {Guest_No}";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(sql, connection);
                using (SqlDataReader dataReader = command.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Booking booking = new Booking();
                        booking.BookingId = Convert.ToInt32(dataReader[0]);
                        booking.HotelNo = Convert.ToInt32(dataReader[1]);
                        booking.GuestNo = Convert.ToInt32(dataReader[2]);
                        booking.DateFrom = Convert.ToDateTime(dataReader[3]);
                        booking.DateTo = Convert.ToDateTime(dataReader[4]);
                        booking.RoomNo = Convert.ToInt32(dataReader[5]);
                        lst.Add(booking);
                    }
                }
                return lst;
            }
        }
    }
}
