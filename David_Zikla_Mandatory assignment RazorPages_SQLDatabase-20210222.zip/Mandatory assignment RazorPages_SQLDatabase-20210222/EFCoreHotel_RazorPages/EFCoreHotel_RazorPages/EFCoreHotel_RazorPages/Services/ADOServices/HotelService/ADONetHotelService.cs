﻿using EFCoreHotel_RazorPages.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EFCoreHotel_RazorPages.Services.ADOServices.HotelService
{
    public class ADONetHotelService
    {
        private IConfiguration configuration { get; }
        public ADONetHotelService(IConfiguration config)
        {
            configuration = config;
        }
        public List<Hotel> GetHotels()
        {
            
            string connectionString = configuration.GetConnectionString("HotelConnection");
            List<Hotel> lst = new List<Hotel>();
            string sql = "Select * From Hotel";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(sql, connection);
                using (SqlDataReader dataReader = command.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Hotel hotel= new Hotel();
                        hotel.HotelNo = Convert.ToInt32(dataReader[0]);
                        hotel.Name= Convert.ToString(dataReader[1]);
                        hotel.Address = Convert.ToString(dataReader[2]);
                        hotel.Rooms = GetROEH(hotel.HotelNo);
                       lst.Add(hotel);
                    }
                }
            }
            return lst;
        }

        public List<Room> GetROEH(int Hotel_No)
        {
            
            string connectionString = configuration.GetConnectionString("HotelConnection");
            List<Room> lst = new List<Room>();
            string sql = $"Select * From Room WHERE Room.Hotel_No = {Hotel_No}";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(sql, connection);
                using (SqlDataReader dataReader = command.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Room room = new Room();
                        room.RoomNo = Convert.ToInt32(dataReader[0]);
                        room.HotelNo = Convert.ToInt32(dataReader[1]);
                        room.Types = Convert.ToString(dataReader[2]);
                        room.Price = Convert.ToDouble(dataReader[3]);
                        lst.Add(room);
                    }
                }
            }
            return lst;
        }

        public List<Guest> GetGP()
        {
            string connectionString = configuration.GetConnectionString("HotelConnection");
            List<Guest> lst = new List<Guest>();
            string sql = "Select Guest.Guest_No, Guest.Name, Guest.Address, price from Room inner join Booking on Room.Room_No = Booking.Room_No and Room.Hotel_No = Booking.Hotel_No inner join Guest on Guest.Guest_No = Booking.Guest_No where Booking.Date_From <= '2011-02-14'and Booking.Date_To >= '2011-02-14'and Booking.Hotel_No = 6";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(sql, connection);
                using (SqlDataReader dataReader = command.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Guest guest = new Guest();
                        Booking booking = new Booking();
                        Room room = new Room();
                        guest.GuestNo = Convert.ToInt32(dataReader[0]);
                        guest.Name = Convert.ToString(dataReader[1]);
                        guest.Address = Convert.ToString(dataReader[2]);
                        room.Price = Convert.ToInt32(dataReader[3]);
                        booking.Room = room;
                        guest.Bookings.Add(booking);
                        lst.Add(guest);
                    }
                }
            }
            return lst;
        }

        public Dictionary<string, int> GetMarch()
        {
            string connectionString = configuration.GetConnectionString("HotelConnection");
            Dictionary<string, int> lst = new Dictionary<string, int>();
            string sql = "select Name, COUNT(Booking_id)as Count from Hotel inner join Booking on Hotel.Hotel_No = Booking.Hotel_No where Date_From between '2011-03-01' and '2011-03-31' or Date_To between '2011-03-01' and '2011-03-31' group by Name";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(sql, connection);
                using (SqlDataReader dataReader = command.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        lst.Add(Convert.ToString(dataReader[0]), Convert.ToInt32(dataReader[1]));
                    }
                }
            }
            return lst;
        }
    }
}
