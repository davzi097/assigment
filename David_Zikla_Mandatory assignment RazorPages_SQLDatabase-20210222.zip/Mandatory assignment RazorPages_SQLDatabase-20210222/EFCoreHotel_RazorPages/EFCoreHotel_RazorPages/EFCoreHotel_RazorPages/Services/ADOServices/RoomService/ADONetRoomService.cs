﻿using EFCoreHotel_RazorPages.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EFCoreHotel_RazorPages.Services.ADOServices.RoomService
{
    public class ADONetRoomService
    {
        private IConfiguration configuration { get; }
        public ADONetRoomService(IConfiguration config)
        {
            configuration = config;
        }
        public List<Room> GetRooms()
        {
            string connectionString = configuration.GetConnectionString("HotelConnection");
            List<Room> lst = new List<Room>();
            string sql = "Select * From Room ";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(sql, connection);
                using (SqlDataReader dataReader = command.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Room room = new Room();
                        room.RoomNo = Convert.ToInt32(dataReader[0]);
                        room.HotelNo = Convert.ToInt32(dataReader[1]);
                        room.Types = Convert.ToString(dataReader[2]);
                        room.Price = Convert.ToDouble(dataReader[3]);
                        lst.Add(room);
                    }
                }
            }
            return lst;
        }

        public List<Room> GetD400()
        {
            string connectionString = configuration.GetConnectionString("HotelConnection");
            List<Room> lst = new List<Room>();
            string sql = "Select * From Room WHERE Types LIKE 'D%' AND Price < 400";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(sql, connection);
                using (SqlDataReader dataReader = command.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Room room = new Room();
                        room.RoomNo = Convert.ToInt32(dataReader[0]);
                        room.HotelNo = Convert.ToInt32(dataReader[1]);
                        room.Types = Convert.ToString(dataReader[2]);
                        room.Price = Convert.ToDouble(dataReader[3]);
                        lst.Add(room);
                    }
                }
            }
            return lst;
        }

        public List<Booking> GetBGFR(int Hotel_No, int Room_No)
        {
            string connectionString = configuration.GetConnectionString("HotelConnection");
            List<Booking> lst = new List<Booking>();
            string sql = $"select * from booking join Guest on Booking.Guest_No = Guest.Guest_No where Hotel_No = {Hotel_No} and Room_No = {Room_No}";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(sql, connection);
                using (SqlDataReader dataReader = command.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Booking booking = new Booking();
                        booking.BookingId = Convert.ToInt32(dataReader[0]);
                        booking.HotelNo = Convert.ToInt32(dataReader[1]);
                        booking.GuestNo = Convert.ToInt32(dataReader[2]);
                        booking.DateFrom = Convert.ToDateTime(dataReader[3]);
                        booking.DateTo = Convert.ToDateTime(dataReader[4]);
                        booking.RoomNo = Convert.ToInt32(dataReader[5]);
                        Guest guest = new Guest();
                        guest.Name = Convert.ToString(dataReader[7]);
                        guest.Address = Convert.ToString(dataReader[8]);
                        booking.GuestNoNavigation = guest;
                       
                        
                        lst.Add(booking);
                    }
                }
            }
            return lst;
        }
    }
}
