﻿using EFCoreHotel_RazorPages.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EFCoreHotel_RazorPages.Services.Interface
{
  public   interface IHotelService
    {
        public IEnumerable<Hotel> GetHotels();

        public IEnumerable<Room> GetROEH(int Hotel_No);

        public IEnumerable<Guest> GetGP();

        public IDictionary<string, int> GetMarch();
    }
}
