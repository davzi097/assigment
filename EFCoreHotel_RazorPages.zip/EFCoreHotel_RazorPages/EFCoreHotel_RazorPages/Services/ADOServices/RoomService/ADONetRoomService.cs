﻿using EFCoreHotel_RazorPages.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EFCoreHotel_RazorPages.Services.ADOServices.RoomService
{
    public class ADONetRoomService
    {
        private IConfiguration configuration { get; }
        public ADONetRoomService(IConfiguration config)
        {
            configuration = config;
        }
        public List<Room> GetRooms()
        {
            string connectionString = configuration.GetConnectionString("HotelConnection");
            List<Room> lst = new List<Room>();
            string sql = "Select * From Room ";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(sql, connection);
                using (SqlDataReader dataReader = command.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Room room = new Room();
                        room.RoomNo = Convert.ToInt32(dataReader[0]);
                        room.HotelNo = Convert.ToInt32(dataReader[1]);
                        room.Types = Convert.ToString(dataReader[2]);
                        room.Price = Convert.ToDouble(dataReader[3]);
                        lst.Add(room);
                    }
                }
            }
            return lst;
        }

        public List<Room> GetD400()
        {
            string connectionString = configuration.GetConnectionString("HotelConnection");
            List<Room> lst = new List<Room>();
            string sql = "Select * From Room WHERE Types LIKE 'D%' AND Price < 400";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(sql, connection);
                using (SqlDataReader dataReader = command.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Room room = new Room();
                        room.RoomNo = Convert.ToInt32(dataReader[0]);
                        room.HotelNo = Convert.ToInt32(dataReader[1]);
                        room.Types = Convert.ToString(dataReader[2]);
                        room.Price = Convert.ToDouble(dataReader[3]);
                        lst.Add(room);
                    }
                }
            }
            return lst;
        }
        public List<Room> GetROEH()
        {
            string connectionString = configuration.GetConnectionString("HotelConnection");
            List<Room> lst = new List<Room>();
            string sql = "Select * From Room WHERE Room.Hotel_No = Hotel.Hotel_No";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(sql, connection);
                using (SqlDataReader dataReader = command.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Room room = new Room();
                        room.RoomNo = Convert.ToInt32(dataReader[0]);
                        room.HotelNo = Convert.ToInt32(dataReader[1]);
                        room.Types = Convert.ToString(dataReader[2]);
                        room.Price = Convert.ToDouble(dataReader[3]);
                        lst.Add(room);
                    }
                }
            }
            return lst;
        }

    }
}
